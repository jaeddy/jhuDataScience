#if !defined(MENU_H)
#define MENU_H

int textMenu(const char *Title, char const* Item[] ,int NoItems) ;

#endif


#if !defined(ERROR_H)
#define ERROR_H

void merror(const char* Msg1, const char*Msg2) ;
void stop(const char* Msg1, const char* Msg2) ;

#endif


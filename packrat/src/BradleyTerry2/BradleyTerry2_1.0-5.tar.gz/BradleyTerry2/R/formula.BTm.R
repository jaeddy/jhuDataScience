formula.BTm <- function(x, ...) x$formula

